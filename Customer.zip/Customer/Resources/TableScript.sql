CREATE TABLE Customer(
customer_id NUMBER PRIMARY KEY,
customer_name VARCHAR2(20),
age NUMBER(3),
phone NUMBER(10),
product_intrested VARCHAR2(20),
reg_date DATE);

CREATE SEQUENCE customer_id
START WITH 1000;