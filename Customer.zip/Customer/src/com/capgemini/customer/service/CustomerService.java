package com.capgemini.customer.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.customer.bean.CustomerBean;
import com.capgemini.customer.dao.CustomerDAO;
import com.capgemini.customer.dao.ICustomerDAO;
import com.capgemini.customer.exception.CustomerException;



public class CustomerService implements ICustomerService{
ICustomerDAO customerDao;
private Matcher ageMatcher;






//------------------------ 1. Customer Application --------------------------
/*******************************************************************************************************
 - Function Name	:	addCustomerDetails
 - Input Parameters	:	customer object
 - Return Type		:	String id
 - Throws			:  	CustomerException
 - Author			:	PUJA
 - Creation Date	:	23/10/2018
 - Description		:	adding customer to database calls dao method addCustomerDetails(customer)
 ********************************************************************************************************/


public String addCustomerDetails(CustomerBean customer) throws CustomerException {
	customerDao=new CustomerDAO();
	String customerSeq;
	customerSeq= customerDao.addCustomerDetails(customer);
	return customerSeq; 
	
}

/*******************************************************************************************************
- Function Name	: validateDonor(DonorBean bean)
- Input Parameters	: DonorBean bean
- Return Type		: void
- Throws		    : DonorException
- Author	      	: CAPGEMINI
- Creation Date	: 18/11/2016
- Description		: validates the DonorBean object
********************************************************************************************************/
public void validateCustomer(CustomerBean bean) throws CustomerException
{
	List<String> validationErrors = new ArrayList<String>();

	//Validating customer name
	if(!(isValidName(bean.getCustomerName()))) {
		validationErrors.add("\n Customer Name Should Be In Alphabets and minimum 3 characters long ! \n");
	}
	
	//Validating Phone Number
	if(!(isValidPhoneNumber(bean.getPhoneNumber()))){
		validationErrors.add("\n Phone Number Should be in 10 digit \n");
	}
	//Validating customer Age
	if(!(isValidAge(bean.getAge()))){
		validationErrors.add("\n Age Should be a positive Number \n" );
		
	}
	if(!(isValidProductInterested(bean.getProductInterested()))){
		validationErrors.add("\n Address Should Be Greater Than 5 Characters \n");
	}
	
	
	
	
	if(!validationErrors.isEmpty())
		throw new CustomerException(validationErrors +"");
}



public boolean isValidName(String customerName){
	Pattern namePattern=Pattern.compile("^[A-Za-z]{3,}$");
	Matcher nameMatcher=namePattern.matcher(customerName);
	return nameMatcher.matches();
}
public boolean isValidProductInterested(String address){
	return (address.length() > 6);
}

public boolean isValidPhoneNumber(String i){
	Pattern phonePattern=Pattern.compile("^[1-9]{1}[0-9]{9}$");
	Matcher phoneMatcher=phonePattern.matcher(i);
	return phoneMatcher.matches();
	
}
public boolean isValidAge(String age){
	Pattern namePattern=Pattern.compile("");
	Matcher nameMatcher=namePattern.matcher(age);
	return ageMatcher.matches();
	
}
public boolean validateCustomerId(String CustomerId) {
	
	Pattern idPattern = Pattern.compile("[0-9]{1,4}");
	Matcher idMatcher = idPattern.matcher(CustomerId);
	
	if(idMatcher.matches())
		return true;
	else
		return false;		
}
	
	
	


	
}
