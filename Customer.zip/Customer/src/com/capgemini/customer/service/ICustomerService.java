package com.capgemini.customer.service;

import com.capgemini.customer.bean.CustomerBean;
import com.capgemini.customer.exception.CustomerException;

public interface ICustomerService {
	public String addCustomerDetails(CustomerBean customer) throws CustomerException;

}
