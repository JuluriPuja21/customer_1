package com.capgemini.customer.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.customer.bean.CustomerBean;
import com.capgemini.customer.exception.CustomerException;
import com.capgemini.customer.util.DBConnection;



public class CustomerDAO implements ICustomerDAO{

	Logger logger=Logger.getRootLogger();
	public CustomerDAO()
	{
	PropertyConfigurator.configure("resources//log4j.properties");
	
	}
	

	//------------------------ 1. Customer Application --------------------------
	/*******************************************************************************************************
	 - Function Name	:	addCustomerDetails(CustomerBean customer)
	 - Input Parameters	:	CustomerBean customer
	 - Return Type		:	String
	 - Throws			:  	CustomerException
	 - Author			:	PUJA
	 - Creation Date	:	23/10/2018
	 - Description		:	Adding customer
	 ********************************************************************************************************/

	public String addCustomerDetails(CustomerBean customer) throws CustomerException 
	{
		Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		
		String customerId=null;
		
		int queryResult=0;
		try
		{		
			preparedStatement=connection.prepareStatement(QueryMapper.INSERT_QUERY);

			preparedStatement.setString(1,customer.getCustomerName());			
			preparedStatement.setString(2,customer.getAge());
			preparedStatement.setString(3,customer.getPhoneNumber());
			preparedStatement.setString(4,customer.getProductInterested());			
			
			queryResult=preparedStatement.executeUpdate();
		
			preparedStatement = connection.prepareStatement(QueryMapper.CUSTOMER_ID_QUERY_SEQUENCE);
			resultSet=preparedStatement.executeQuery();

			if(resultSet.next())
			{
				customerId=resultSet.getString(1);
						
			}
	
			if(queryResult==0)
			{
				logger.error("Insertion failed ");
				 throw new CustomerException("Inserting customer details failed ");

			}
			else
			{
				logger.info("Customer details added successfully:");
				return customerId;
			}

		}
		catch(SQLException sqlException)
		{
			sqlException.printStackTrace();
			logger.error(sqlException.getMessage());
			throw new CustomerException("Tehnical problem occured refer log");
		}

		finally
		{
			try 
			{
				//resultSet.close();
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				sqlException.printStackTrace();
				logger.error(sqlException.getMessage());
				throw new CustomerException("Error in closing db connection");

			}
		}
		
		
	}

}
