package com.capgemini.customer.dao;

public class QueryMapper {
	
	
	public static final String INSERT_QUERY="INSERT INTO Customer VALUES(Customer_id.NEXTVAL,?,?,?,SYSDATE,?)";
	public static final String CUSTOMER_ID_QUERY_SEQUENCE="SELECT customer_id_sequence.CURRVAL FROM DUAL";
	
	}
