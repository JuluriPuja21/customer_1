package com.capgemini.customer.ui;

import java.util.InputMismatchException;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.customer.bean.CustomerBean;
import com.capgemini.customer.exception.CustomerException;
import com.capgemini.customer.service.CustomerService;
import com.capgemini.customer.service.ICustomerService;






public class CustomerMain {
	static Scanner sc = new Scanner(System.in);
	static ICustomerService customerService = null;
	static CustomerService customerServiceImpl = null;
	static Logger logger = Logger.getRootLogger();


	public static void main(String[] args) {
		
		PropertyConfigurator.configure("Resources//log4j.properties");
		CustomerBean customerBean = null;

		String customerId = null;
		int option = 0;

		while (true) {

			// show menu
			System.out.println();
			System.out.println();
			System.out.println("   Customer Application ");
			System.out.println("_______________________________\n");
			System.out.println("1.Add Customer ");
			System.out.println("2.Exit");
			System.out.println("________________________________");
			System.out.println("Select an option:");
			// accept option

	
	
		try {

			option = sc.nextInt();
			switch(option)
			{
			case 1:
				while (customerBean == null) {
				customerBean = populateCustomerBean();
				// System.out.println(customerBean);
			}
				try {
			customerService = new CustomerService();
			customerId = customerService.addCustomerDetails(customerBean);

			System.out.println("Customer details  has been successfully registered ");
			System.out.println("customer  ID Is: " + customerId);

		} catch (CustomerException customerException) {
			logger.error("exception occured", customerException);
			System.out.println("ERROR : "
					+ customerException.getMessage());
		} 
		finally {
			customerId = null;
			customerService = null;
			customerBean = null;
		}
		
		break;	
		case 2:System.exit(0);
		break;
		default:
			System.out.println("enter valid input");
			
			
		
		}
		}
		catch(InputMismatchException e){
			sc.nextLine();
			System.out.println("error :" +e.getMessage());
		}


		}
			
		}
			
	
	/*
	 * This function will be called by main and will return a validated bean
	 * object OR null if details are invalid
	 */
	private static CustomerBean populateCustomerBean() {

		// Reading and setting the values for the donorBean
		
		CustomerBean customerBean = new CustomerBean();;

		System.out.println("\n Enter Details");

		System.out.println("Enter customer name: ");
		customerBean.setCustomerName(sc.next());

		System.out.println("Enter customer contact: ");
		customerBean.setPhoneNumber(sc.next());
		System.out.println("Enter customer age ");
		customerBean.setAge(sc.next());
		System.out.println("Enter product interested ");
		customerBean.setProductInterested(sc.next());


		customerServiceImpl= new CustomerService();

		try {
			customerServiceImpl.validateCustomer(customerBean);
			return customerBean;
		} catch (CustomerException customerException) {
			logger.error("exception occured", customerException);
			System.err.println("Invalid data:");
			System.err.println(customerException.getMessage() + " \n Try again..");
			System.exit(0);

		}
		return null;

	}
}